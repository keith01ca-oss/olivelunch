import { supabaseAdmin } from '@/lib/supabase';
import OrdersClient from '@/components/admin/OrdersClient';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: { date?: string; status?: string };
}) {
  const dateFilter = searchParams.date || '';
  const statusFilter = searchParams.status || '';

  let query = supabaseAdmin
    .from('orders')
    .select(`
      id,
      order_date,
      status,
      gross_amount,
      total_amount,
      created_at,
      children ( 
        id, 
        name, 
        division,
        schools (
          id,
          name,
          school_routes (
            stop_order,
            routes (
              id,
              route_number
            )
          )
        )
      ),
      parents ( id, name, email ),
      order_items (
        id,
        quantity,
        unit_price,
        total_price,
        dishes ( id, name, category )
      )
    `)
    .order('order_date', { ascending: false })
    .order('created_at', { ascending: false });

  if (dateFilter) query = query.eq('order_date', dateFilter);
  if (statusFilter) query = query.eq('status', statusFilter);

  const { data: orders, error } = await query;

  if (error) console.error('Orders fetch error:', error);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight">Orders</h1>
        <p className="text-muted-foreground mt-1">View and manage all lunch orders.</p>
      </div>
      <OrdersClient initialOrders={orders || []} />
    </div>
  );
}
