import { supabaseAdmin } from '@/lib/supabase';
import { cookies } from 'next/headers';
import PlannerClient from '@/components/admin/PlannerClient';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminPlannerPage() {
  const orgId = cookies().get('olive_org_id')?.value;

  // Fetch active dishes
  let dishQuery = supabaseAdmin
    .from('dishes')
    .select('*')
    .eq('is_active', true)
    .is('deleted_at', null)
    .order('category')
    .order('sort_order', { ascending: true });
  
  if (orgId) dishQuery = dishQuery.eq('org_id', orgId);
  const { data: dishes } = await dishQuery;

  // Fetch blocked dates to display them on the calendar
  let bdQuery = supabaseAdmin.from('blocked_dates').select('*');
  if (orgId) bdQuery = bdQuery.eq('org_id', orgId);
  const { data: blockedDates } = await bdQuery;

  // Fetch Org Settings
  let orgData = null;
  if (orgId) {
    const { data } = await supabaseAdmin.from('organizations').select('id, settings').eq('id', orgId).single();
    orgData = data;
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight">Menu Planner</h1>
        <p className="text-muted-foreground mt-1">Drag and drop dishes onto the calendar to schedule your daily menus.</p>
      </div>

      <PlannerClient 
        initialDishes={dishes || []} 
        blockedDates={blockedDates || []}
        org={orgData}
      />
    </div>
  );
}
