import { cookies } from 'next/headers';
import { supabaseAdmin } from '@/lib/supabase';
import SettingsClient from '@/components/admin/SettingsClient';
import { redirect } from 'next/navigation';

export default async function AdminSettingsPage() {
  const orgId = cookies().get('olive_org_id')?.value;
  if (!orgId) redirect('/admin');

  const { data: org } = await supabaseAdmin
    .from('organizations')
    .select('*')
    .eq('id', orgId)
    .single();

  if (!org) redirect('/admin');

  return <SettingsClient org={org} />;
}
