import { supabaseAdmin } from '@/lib/supabase';
import { cookies } from 'next/headers';
import DishesClient from '@/components/admin/DishesClient';

export default async function AdminDishesPage() {
  const orgId = cookies().get('olive_org_id')?.value;

  let dishQuery = supabaseAdmin
    .from('dishes')
    .select('*')
    .is('deleted_at', null)
    .order('category')
    .order('sort_order', { ascending: true });
  if (orgId) dishQuery = dishQuery.eq('org_id', orgId);
  const { data: dishes } = await dishQuery;

  const { data: org } = orgId ? await supabaseAdmin.from('organizations').select('settings').eq('id', orgId).single() : { data: null };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Manage Dishes & Recipes</h1>
          <p className="text-muted-foreground mt-1">Add, edit, and manage your menu items, recipes, and costs.</p>
        </div>
      </div>
      <DishesClient initialDishes={dishes || []} orgSettings={org?.settings} />
    </div>
  );
}
