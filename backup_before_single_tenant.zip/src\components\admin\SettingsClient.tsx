'use client';

import { useState } from 'react';
import { Settings, Plus, Trash2, Save, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function SettingsClient({ org }: { org: any }) {
  const [categories, setCategories] = useState<string[]>(org?.settings?.categories || ['main', 'side', 'snack', 'drink']);
  const [units, setUnits] = useState<string[]>(org?.settings?.units || ['g', 'kg', 'ml', 'L', 'cups', 'tbsp', 'tsp', 'pcs', 'oz', 'lbs', 'slices', 'cans', 'bags', 'chunk', 'pinch']);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const newSettings = { 
        ...(org.settings || {}), 
        categories: categories.filter(c => c.trim() !== '').map(c => c.toLowerCase().trim()),
        units: units.filter(u => u.trim() !== '').map(u => u.trim())
      };

      const res = await fetch(`/api/admin/orgs/${org.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: newSettings })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      toast.success('Settings updated successfully');
    } catch (err: any) {
      toast.error(err.message || 'Failed to save settings');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary" /> System Settings
          </h1>
          <p className="text-muted-foreground">Manage your global categories, units, and system defaults.</p>
        </div>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-primary text-primary-foreground px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-primary/90 transition-colors shadow-sm disabled:opacity-50"
        >
          {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save Changes
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Category Management */}
        <div className="bg-card border rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b pb-2">
            <h2 className="font-bold text-primary uppercase tracking-wider text-sm">Menu Categories</h2>
            <button 
              onClick={() => setCategories([...categories, ''])}
              className="p-1 hover:bg-primary/10 text-primary rounded-lg transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-muted-foreground">These appear in the "Category" dropdown when creating dishes.</p>
          
          <div className="space-y-2">
            {categories.map((cat, i) => (
              <div key={i} className="flex items-center gap-2">
                <input 
                  value={cat}
                  onChange={(e) => {
                    const next = [...categories];
                    next[i] = e.target.value;
                    setCategories(next);
                  }}
                  placeholder="Category name..."
                  className="flex-1 h-10 rounded-lg border px-3 text-sm focus:ring-1 focus:ring-primary outline-none bg-background"
                />
                <button 
                  onClick={() => setCategories(categories.filter((_, idx) => idx !== i))}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Unit Management */}
        <div className="bg-card border rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b pb-2">
            <h2 className="font-bold text-primary uppercase tracking-wider text-sm">Ingredient Units</h2>
            <button 
              onClick={() => setUnits([...units, ''])}
              className="p-1 hover:bg-primary/10 text-primary rounded-lg transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-muted-foreground">These appear in the "Unit" dropdown for recipes.</p>

          <div className="grid grid-cols-2 gap-2">
            {units.map((unit, i) => (
              <div key={i} className="flex items-center gap-1">
                <input 
                  value={unit}
                  onChange={(e) => {
                    const next = [...units];
                    next[i] = e.target.value;
                    setUnits(next);
                  }}
                  placeholder="Unit..."
                  className="flex-1 h-9 rounded-lg border px-2 text-xs focus:ring-1 focus:ring-primary outline-none bg-background font-mono"
                />
                <button 
                  onClick={() => setUnits(units.filter((_, idx) => idx !== i))}
                  className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
