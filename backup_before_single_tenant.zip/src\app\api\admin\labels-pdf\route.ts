import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import PDFDocument from 'pdfkit';

// Avery 5160 specs (all in points: 1 inch = 72pt)
const PT = 72; // points per inch
const PAGE_W = 8.5 * PT;   // 612pt
const PAGE_H = 11 * PT;    // 792pt
const TOP_MARGIN = 0.5 * PT;    // 36pt
const SIDE_MARGIN = 0.19 * PT;  // 13.68pt
const LABEL_W = 2.625 * PT;    // 189pt
const LABEL_H = 1.0 * PT;      // 72pt
const COL_GAP = 0.125 * PT;    // 9pt
const ROW_GAP = 0;
const COLS = 3;
const ROWS = 10;

// String hash function for consistent colors/shapes
function getStringHash(str: string) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash);
}

// Golden angle color palette for divisions, using hash for consistency
function getDivisionColor(div: string): string {
  const hash = getStringHash(div);
  const hue = (hash * 137.5) % 360;
  // Return hex approximation from HSL
  const h = hue / 360;
  // Use lower lightness and higher saturation for darker, more printable colors
  const s = 0.85;
  const l = 0.45;
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const hue2rgb = (t: number) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1/6) return p + (q - p) * 6 * t;
    if (t < 1/2) return q;
    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
    return p;
  };
  const r = Math.round(hue2rgb(h + 1/3) * 255);
  const g = Math.round(hue2rgb(h) * 255);
  const b = Math.round(hue2rgb(h - 1/3) * 255);
  return `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
}

// Generates a consistent shape and color for a school
function getSchoolSymbol(schoolName: string) {
  if (!schoolName) return { shape: 0, color: '#333333' };
  const hash = getStringHash(schoolName);
  const colors = ['#E63946', '#2A9D8F', '#D66853', '#F4A261', '#264653', '#8338EC', '#3A86FF', '#D90429', '#023E8A', '#0077B6', '#0096C7'];
  const shapeIdx = hash % 5;
  const colorIdx = (Math.floor(hash / 5)) % colors.length;
  return { shape: shapeIdx, color: colors[colorIdx] };
}

export const dynamic = 'force-dynamic';

import { cookies } from 'next/headers';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const date = searchParams.get('date');
  const orgId = cookies().get('olive_org_id')?.value;

  if (!date) {
    return NextResponse.json({ error: 'date required' }, { status: 400 });
  }

  // Fetch orders
  let query = supabaseAdmin
    .from('orders')
    .select(`
      id,
      order_items (dish_id, quantity),
      children (name, division, delivery_location, lunch_time, schools(name, school_routes(stop_order, routes(route_number))))
    `)
    .eq('order_date', date)
    .eq('status', 'paid');

  if (orgId) query = query.eq('org_id', orgId);
  const { data: orders, error } = await query;
  if (error || !orders) {
    return NextResponse.json({ error: error?.message || 'No data' }, { status: 500 });
  }

  // Fetch dishes
  let dishQuery = supabaseAdmin
    .from('dishes')
    .select('id, name')
    .eq('is_active', true)
    .is('deleted_at', null);
  if (orgId) dishQuery = dishQuery.eq('org_id', orgId);
  const { data: dishes } = await dishQuery;
  const dishMap: Record<string, string> = {};
  (dishes || []).forEach((d: any) => { dishMap[d.id] = d.name; });

  // Assign colors to divisions
  const uniqueDivs = Array.from(new Set(orders.map((o: any) => o.children?.division).filter(Boolean)));
  const divColorMap: Record<string, string> = {};
  uniqueDivs.forEach((div) => { divColorMap[div as string] = getDivisionColor(div as string); });

  // Flatten: 1 label per item per quantity
  const labels: any[] = [];
  orders.forEach((order: any) => {
    order.order_items.forEach((item: any) => {
      for (let q = 0; q < item.quantity; q++) {
        labels.push({
          childName: order.children?.name || '',
          division: order.children?.division || '',
          deliveryLocation: order.children?.delivery_location || '',
          lunchTime: order.children?.lunch_time || '',
          schoolName: (order.children?.schools as any)?.name || '',
          stopOrder: (order.children?.schools as any)?.school_routes?.[0]?.stop_order || 0,
          routeNumber: (order.children?.schools as any)?.school_routes?.[0]?.routes?.route_number || '',
          dishName: dishMap[item.dish_id] || '',
          itemNum: q + 1,
          totalQty: item.quantity,
          color: divColorMap[order.children?.division] || '#cccccc',
        });
      }
    });
  });

  // Sort by division then name
  labels.sort((a, b) => {
    const dc = a.division.localeCompare(b.division);
    return dc !== 0 ? dc : a.childName.localeCompare(b.childName);
  });

  // Format date
  const printDate = new Date(date + 'T00:00:00').toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });

  // Build PDF
  const buffers: Buffer[] = [];
  const doc = new PDFDocument({
    size: [PAGE_W, PAGE_H],
    margin: 0,
    autoFirstPage: true,
    info: { Title: `Packing Labels - ${date}`, Author: 'Olive Lunch' },
  });

  doc.on('data', (chunk: Buffer) => buffers.push(chunk));

  const drawLabel = (label: any, col: number, row: number) => {
    const x = SIDE_MARGIN + col * (LABEL_W + COL_GAP);
    const y = TOP_MARGIN + row * (LABEL_H + ROW_GAP);

    const stripW = 4;
    const padL = 24; // Massive left padding to push column 1 right
    const padT = 14; // Massive top padding to push row 1 down
    const padR = 16; // Massive right padding to push column 3 left
    const textW = LABEL_W - padL - padR;

    // Left color strip (pulled inward to x+12 and padded top/bottom)
    doc.save();
    try {
      doc.roundedRect(x + 12, y + padT, stripW, LABEL_H - (padT * 2), 2).fill(label.color);
    } catch { /* ignore color errors */ }
    doc.restore();

    // ROW 1: Name + Division badge
    doc.save()
      .font('Helvetica-Bold')
      .fontSize(7.5) // slightly smaller to fit compressed width
      .fillColor('black')
      .text(
        label.childName.toUpperCase(),
        x + padL,
        y + padT,
        { width: textW - 32, ellipsis: true, lineBreak: false }
      )
      .restore();

    // Division badge (right of name)
    doc.save()
      .roundedRect(x + LABEL_W - padR - 30, y + padT - 1, 30, 9, 1)
      .stroke(label.color)
      .font('Helvetica-Bold')
      .fontSize(6)
      .fillColor('black')
      .text(label.division, x + LABEL_W - padR - 30, y + padT + 0.5, { width: 30, align: 'center', lineBreak: false })
      .restore();

    // ROW 2: Delivery + time
    doc.save()
      .font('Helvetica-Bold')
      .fontSize(5.5)
      .fillColor('#222222')
      .text(
        `${(label.deliveryLocation || '').toUpperCase()}`,
        x + padL, y + padT + 11,
        { width: textW / 2 + 10, lineBreak: false }
      )
      .text(
        label.lunchTime,
        x + padL + textW / 2 - 10, y + padT + 11,
        { width: textW / 2 + 10, align: 'right', lineBreak: false }
      )
      .restore();

    // Dashed divider line
    doc.save()
      .moveTo(x + padL, y + padT + 19)
      .lineTo(x + LABEL_W - padR, y + padT + 19)
      .dash(2, { space: 2 })
      .strokeColor('#888888')
      .lineWidth(0.4)
      .stroke()
      .restore();

    // ROW 3: Dish name
    const dishText = label.totalQty > 1
      ? `${label.dishName}  (${label.itemNum}/${label.totalQty})`
      : label.dishName;
    doc.save()
      .font('Helvetica-Bold')
      .fontSize(7)
      .fillColor('black')
      .text(dishText, x + padL, y + padT + 23, { width: textW, ellipsis: true, lineBreak: false })
      .restore();

    // ROW 4a: School Icon + School Name (large bold caps)
    const schoolSym = getSchoolSymbol(label.schoolName);
    const symSize = 3.5;
    const symX = x + padL + symSize;
    const symY = y + LABEL_H - 22;

    doc.save().fillColor(schoolSym.color);
    switch(schoolSym.shape) {
      case 0: doc.circle(symX, symY, symSize).fill(); break; // Circle
      case 1: doc.rect(symX - symSize, symY - symSize, symSize*2, symSize*2).fill(); break; // Square
      case 2: doc.polygon([symX, symY - symSize], [symX + symSize, symY + symSize], [symX - symSize, symY + symSize]).fill(); break; // Triangle up
      case 3: doc.polygon([symX, symY - symSize], [symX + symSize, symY], [symX, symY + symSize], [symX - symSize, symY]).fill(); break; // Diamond
      case 4: doc.polygon([symX - symSize, symY - symSize], [symX + symSize, symY - symSize], [symX, symY + symSize]).fill(); break; // Triangle down
    }
    doc.restore();

    doc.save()
      .font('Helvetica-Bold')
      .fontSize(7)
      .fillColor('black')
      .text(label.schoolName.toUpperCase(), x + padL + symSize*2 + 4, y + LABEL_H - 25.5, { width: textW * 0.75 - symSize*2 - 4, ellipsis: true, lineBreak: false })
      .restore();

    // ROW 4b: Route + Stop (smaller) + Date
    let routeText = '';
    if (label.routeNumber) routeText += `Rt ${label.routeNumber}`;
    if (label.stopOrder > 0) routeText += (routeText ? ` - Stop ${label.stopOrder}` : `Stop ${label.stopOrder}`);

    doc.save()
      .font('Helvetica-Bold')
      .fontSize(5)
      .fillColor('#666666')
      .text(routeText, x + padL, y + LABEL_H - 14, { width: textW * 0.6, ellipsis: true, lineBreak: false })
      .fontSize(5)
      .fillColor('#888888')
      .text(printDate, x + padL + textW * 0.6, y + LABEL_H - 14, { width: textW * 0.4, align: 'right', lineBreak: false })
      .restore();
  };

  // Draw all labels
  labels.forEach((label, i) => {
    const col = i % COLS;
    const row = Math.floor(i / COLS) % ROWS;
    const pageIndex = Math.floor(i / (COLS * ROWS));

    if (i > 0 && col === 0 && row === 0) {
      doc.addPage({ size: [PAGE_W, PAGE_H], margin: 0 });
    }

    drawLabel(label, col, row);
  });

  doc.end();

  const pdfBuffer = await new Promise<Buffer>((resolve) => {
    doc.on('end', () => resolve(Buffer.concat(buffers)));
  });

  return new NextResponse(pdfBuffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="labels-${date}.pdf"`,
      'Content-Length': pdfBuffer.length.toString(),
    },
  });
}
