'use client';

import { useState } from 'react';
import { Building2, Pencil, Save, X, ExternalLink } from 'lucide-react';

interface Organization {
  id: string;
  name: string;
  slug: string;
  stripe_subscription_status: string | null;
  created_at: string;
}

export default function ManagementClient({ initialOrgs }: { initialOrgs: Organization[] }) {
  const [orgs, setOrgs] = useState<Organization[]>(initialOrgs);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ name: '', slug: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const startEditing = (org: Organization) => {
    setEditingId(org.id);
    setEditForm({ name: org.name, slug: org.slug });
    setError('');
  };

  const handleSave = async (id: string) => {
    setSaving(true);
    setError('');
    try {
      const res = await fetch(`/api/admin/orgs/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm)
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      setOrgs(prev => prev.map(o => o.id === id ? { ...o, ...editForm } : o));
      setEditingId(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-card border rounded-2xl shadow-sm overflow-hidden">
      <div className="px-6 py-5 border-b flex items-center gap-3 bg-muted/20">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
          <Building2 className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-xl font-bold">B2B Customers (Organizations)</h2>
          <p className="text-sm text-muted-foreground">Manage your SaaS clients and their subscription status.</p>
        </div>
      </div>

      {error && <div className="p-4 bg-destructive/10 text-destructive text-sm font-medium">{error}</div>}

      <table className="w-full text-sm">
        <thead className="bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
          <tr>
            <th className="px-6 py-4 font-semibold">Organization Name</th>
            <th className="px-6 py-4 font-semibold">URL Slug</th>
            <th className="px-6 py-4 font-semibold">Subscription Status</th>
            <th className="px-6 py-4 font-semibold">Registered</th>
            <th className="px-6 py-4 font-semibold text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {orgs.map((org) => (
            <tr key={org.id} className="hover:bg-muted/20 transition-colors">
              <td className="px-6 py-4">
                {editingId === org.id ? (
                  <input
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full h-8 rounded border px-2 text-sm"
                  />
                ) : (
                  <span className="font-bold">{org.name}</span>
                )}
              </td>
              <td className="px-6 py-4">
                {editingId === org.id ? (
                  <input
                    value={editForm.slug}
                    onChange={(e) => setEditForm({ ...editForm, slug: e.target.value })}
                    className="w-full h-8 rounded border px-2 text-sm"
                  />
                ) : (
                  <div className="flex items-center gap-1.5 font-mono text-muted-foreground">
                    /{org.slug}
                    <a href={`/${org.slug}`} target="_blank" rel="noreferrer" className="hover:text-primary"><ExternalLink className="w-3 h-3" /></a>
                  </div>
                )}
              </td>
              <td className="px-6 py-4">
                {org.stripe_subscription_status === 'active' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-green-100 text-green-700">Active</span>
                ) : org.stripe_subscription_status ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-yellow-100 text-yellow-700">{org.stripe_subscription_status}</span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-muted text-muted-foreground">Free Tier / None</span>
                )}
              </td>
              <td className="px-6 py-4 text-muted-foreground">
                {new Date(org.created_at).toLocaleDateString()}
              </td>
              <td className="px-6 py-4 text-right">
                {editingId === org.id ? (
                  <div className="flex items-center justify-end gap-2">
                    <button onClick={() => setEditingId(null)} className="p-1.5 text-muted-foreground hover:bg-muted rounded"><X className="w-4 h-4" /></button>
                    <button onClick={() => handleSave(org.id)} disabled={saving} className="p-1.5 text-primary hover:bg-primary/10 rounded"><Save className="w-4 h-4" /></button>
                  </div>
                ) : (
                  <button onClick={() => startEditing(org)} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                    <Pencil className="w-4 h-4" />
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
