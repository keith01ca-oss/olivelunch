'use client';

import { useState, useEffect, useMemo } from 'react';
import { format, addDays } from 'date-fns';
import { Printer, Calendar, Download, ChefHat, Clock } from 'lucide-react';

interface Ingredient {
  name: string;
  amount: number;
  unit: string;
}

interface Dish {
  id: string;
  name: string;
  category: string;
  recipe_url?: string;
  ingredients?: Ingredient[];
  prep_time_minutes?: number;
  cook_time_minutes?: number;
  pack_time_seconds?: number;
}

interface OrderItem {
  dish_id: string;
  quantity: number;
}

interface Order {
  id: string;
  order_items: OrderItem[];
}

export default function KitchenClient({ initialDishes, initialDate, initialTab }: { 
  initialDishes: Dish[]; 
  initialDate?: string;
  initialTab?: 'prep' | 'labels' | 'manifest';
}) {
  const [selectedDate, setSelectedDate] = useState<string>(initialDate || format(addDays(new Date(), 1), 'yyyy-MM-dd'));
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'prep' | 'labels' | 'manifest'>(initialTab || 'prep');

  // Fetch orders when date changes
  useEffect(() => {
    async function fetchOrders() {
      if (!selectedDate) return;
      setLoading(true);
      setError('');
      try {
        const res = await fetch(`/api/admin/kitchen?date=${selectedDate}`);
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        setOrders(data.orders || []);
      } catch (e: any) {
        setError(e.message || 'Failed to fetch orders');
      } finally {
        setLoading(false);
      }
    }
    fetchOrders();
  }, [selectedDate]);

  // Color coding for divisions (classrooms)
  const divisionColors = useMemo(() => {
    const uniqueDivs = Array.from(new Set(orders.map(o => o.children?.division).filter(Boolean)));
    const map: Record<string, { bg: string, border: string }> = {};
    
    uniqueDivs.forEach((div: any, i) => {
      // Use Golden Angle (137.5 degrees) to generate distinct colors for each division
      const hue = (i * 137.5) % 360;
      map[div] = {
        bg: `hsl(${hue}, 100%, 94%)`,
        border: `hsl(${hue}, 80%, 75%)`
      };
    });
    return map;
  }, [orders]);

  // Flatten orders into individual labels (1 label per item quantity)
  const labelsToPrint = useMemo(() => {
    const list: any[] = [];
    orders.forEach(order => {
      order.order_items.forEach((item: any) => {
        for (let q = 0; q < item.quantity; q++) {
          list.push({
            orderId: order.id,
            child: order.children,
            dishId: item.dish_id,
            itemNumber: q + 1,
            totalQuantity: item.quantity
          });
        }
      });
    });
    // Sort by division, then child name
    return list.sort((a, b) => {
      const divCompare = (a.child?.division || '').localeCompare(b.child?.division || '');
      if (divCompare !== 0) return divCompare;
      return (a.child?.name || '').localeCompare(b.child?.name || '');
    });
  }, [orders]);

  // Aggregate Data
  const { mealTotals, ingredientTotals, totalPrepTime, totalCookTime, totalPackSeconds } = useMemo(() => {
    const mealMap: Record<string, number> = {};
    const ingMap: Record<string, { amount: number; unit: string }> = {};
    let prep = 0, cook = 0, packSeconds = 0;

    orders.forEach(order => {
      order.order_items.forEach((item: any) => {
        mealMap[item.dish_id] = (mealMap[item.dish_id] || 0) + item.quantity;
      });
    });

    Object.entries(mealMap).forEach(([dishId, totalQty]) => {
      const dish = initialDishes.find(d => d.id === dishId);
      if (dish) {
        if (dish.ingredients) {
          dish.ingredients.forEach(ing => {
            const key = `${ing.name}|${ing.unit}`;
            if (!ingMap[key]) ingMap[key] = { amount: 0, unit: ing.unit };
            ingMap[key].amount += (ing.amount * totalQty);
          });
        }
        prep += (dish.prep_time_minutes || 0);
        cook += (dish.cook_time_minutes || 0);
        packSeconds += ((dish.pack_time_seconds || 0) * totalQty);
      }
    });

    return { mealTotals: mealMap, ingredientTotals: ingMap, totalPrepTime: prep, totalCookTime: cook, totalPackSeconds: packSeconds };
  }, [orders, initialDishes]);

  const uniqueCategories = Array.from(new Set(initialDishes.map(d => d.category)));

  const [downloading, setDownloading] = useState(false);

  const handlePrint = () => window.print();

  const handleDownloadPDF = async () => {
    setDownloading(true);
    try {
      // Add timestamp to prevent browser from caching the PDF when new orders are added
      const res = await fetch(`/api/admin/labels-pdf?date=${selectedDate}&t=${Date.now()}`);
      if (!res.ok) throw new Error('Failed to generate PDF');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `labels-${selectedDate}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert('PDF generation failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Avery 5160 Print Styles */}
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          @page {
            size: 8.5in 11in;
            margin: 0;
          }

          /* White only - no ink waste */
          html, body, * {
            background: white !important;
            background-color: white !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            box-shadow: none !important;
          }

          /* Hide all UI chrome */
          nav, aside, .print\\:hidden,
          .no-print { display: none !important; }

          /* Wrapper: Avery 5160 exact margins (spec: 0.5" top/bottom, 0.19" sides) */
          .labels-print-wrapper {
            display: block !important;
            width: 8.5in !important;
            padding: 0.5in 0.19in !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            background: white !important;
          }

          /* Grid: 3 cols x 10 rows, 0.125" col gap, 0" row gap */
          .labels-print-grid {
            display: grid !important;
            grid-template-columns: 2.625in 2.625in 2.625in !important;
            column-gap: 0.125in !important;
            row-gap: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          /* Label: exactly 2.625in x 1in, NO border (Avery sheet has its own) */
          .avery-label {
            width: 2.625in !important;
            height: 1in !important;
            min-height: 1in !important;
            max-height: 1in !important;
            overflow: hidden !important;
            box-sizing: border-box !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            border-radius: 0 !important;
            border: none !important;
            padding: 5pt 5pt 3pt 6pt !important;
            display: flex !important;
            flex-direction: column !important;
            justify-content: flex-start !important;
            gap: 1.5pt !important;
            background: white !important;
            color: black !important;
          }

          /* Name + Div on same line */
          .avery-label .label-row1 {
            display: flex !important;
            align-items: baseline !important;
            gap: 4pt !important;
          }
          .avery-label .label-name {
            font-size: 9pt !important;
            font-weight: 900 !important;
            text-transform: uppercase !important;
            line-height: 1 !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            flex: 1 !important;
            color: black !important;
          }
          .avery-label .label-div-badge {
            font-size: 7pt !important;
            font-weight: 900 !important;
            background: white !important;
            border: 0.5pt solid #333 !important;
            padding: 0.5pt 3pt !important;
            border-radius: 1pt !important;
            flex-shrink: 0 !important;
            color: black !important;
          }

          /* Delivery + time */
          .avery-label .label-row2 {
            display: flex !important;
            justify-content: space-between !important;
            font-size: 6pt !important;
            font-weight: 600 !important;
            color: #333 !important;
            line-height: 1 !important;
            text-transform: uppercase !important;
          }

          /* Dashed separator */
          .avery-label .label-divider {
            border: none !important;
            border-top: 0.4pt dashed #777 !important;
            margin: 2pt 0 !important;
          }

          /* Dish name */
          .avery-label .label-dish {
            display: flex !important;
            align-items: center !important;
            gap: 3pt !important;
            font-size: 8.5pt !important;
            font-weight: 800 !important;
            line-height: 1 !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            color: black !important;
          }

          /* Footer: school + date */
          .avery-label .label-footer {
            display: flex !important;
            justify-content: space-between !important;
            font-size: 5.5pt !important;
            font-weight: 500 !important;
            color: #444 !important;
            margin-top: auto !important;
            line-height: 1 !important;
          }
          .avery-label .label-school {
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            max-width: 70% !important;
          }

          /* Hide screen-only decorations */
          .label-color-strip { display: none !important; }
        }
      `}} />

      
      {/* Controls - Hidden when printing */}
      <div className="bg-card border rounded-2xl p-6 shadow-sm flex flex-col gap-6 print:hidden">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Calendar className="w-4 h-4" /> Prep Date
            </label>
            <input 
              type="date" 
              value={selectedDate} 
              onChange={(e) => setSelectedDate(e.target.value)}
              className="h-10 rounded-lg border border-input bg-background px-3 text-sm focus:ring-1 focus:ring-primary outline-none min-w-[200px]"
            />
          </div>

          <div className="flex items-center gap-2 bg-muted p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('prep')}
              className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${activeTab === 'prep' ? 'bg-card shadow-sm text-primary' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Prep Sheet
            </button>
            <button 
              onClick={() => setActiveTab('labels')}
              className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${activeTab === 'labels' ? 'bg-card shadow-sm text-primary' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Packing Labels
            </button>
            <button 
              onClick={() => setActiveTab('manifest')}
              className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${activeTab === 'manifest' ? 'bg-card shadow-sm text-primary' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Manifest
            </button>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'labels' && (
              <button 
                onClick={handleDownloadPDF}
                disabled={downloading}
                className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold shadow-sm hover:bg-emerald-700 transition-colors h-10 disabled:opacity-60"
              >
                <Download className="w-4 h-4" />
                {downloading ? 'Generating...' : 'Download PDF'}
              </button>
            )}
            {activeTab !== 'labels' && (
              <button 
                onClick={handlePrint}
                className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl font-bold shadow-sm hover:bg-primary/90 transition-colors h-10"
              >
                <Printer className="w-4 h-4" /> Print {activeTab === 'prep' ? 'Prep Sheet' : 'Manifest'}
              </button>
            )}
          </div>
        </div>
      </div>

      {error && <div className="text-destructive bg-destructive/10 p-4 rounded-xl font-medium">{error}</div>}

      {/* Print Headers */}
      {activeTab !== 'labels' && (
        <div className="hidden print:block mb-6 border-b-2 border-black pb-4">
          <h1 className="text-2xl font-black uppercase tracking-tight">
            {activeTab === 'prep' ? 'Kitchen Prep Sheet' : 'Delivery Manifest'}
          </h1>
          <div className="flex justify-between items-center mt-1">
            <p className="text-lg font-bold text-gray-700">{format(new Date(selectedDate), 'EEEE, MMMM d, yyyy')}</p>
            <p className="text-sm font-bold">Total Orders: {orders.length}</p>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-center p-12 text-muted-foreground animate-pulse">Calculating production data...</div>
      ) : orders.length === 0 ? (
        <div className="bg-muted/30 border-2 border-dashed rounded-2xl p-12 text-center text-muted-foreground print:hidden">
          <ChefHat className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="font-medium text-lg">No paid orders found for this date.</p>
          <p className="text-sm">Select another date to view prep requirements.</p>
        </div>
      ) : (
        <div className="animate-fade-in">
          {/* TAB 1: PREP SHEET */}
          {activeTab === 'prep' && (
            <div className="space-y-8">
              <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 shadow-sm print:shadow-none print:border-black">
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-primary print:text-black" />
                  <h2 className="text-xl font-bold">Production Estimate</h2>
                </div>
                <div className="grid grid-cols-3 gap-6 divide-x divide-primary/20">
                  <div className="text-center">
                    <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Total Prep</p>
                    <p className="text-2xl font-black">{totalPrepTime} <span className="text-sm opacity-60">min</span></p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Total Cook</p>
                    <p className="text-2xl font-black">{totalCookTime} <span className="text-sm opacity-60">min</span></p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Total Pack</p>
                    <p className="text-2xl font-black">{Math.ceil(totalPackSeconds / 60)} <span className="text-sm opacity-60">min</span></p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 print:block print:space-y-8">
                <div className="space-y-6">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <ChefHat className="w-6 h-6 text-primary print:text-black" />
                    <h2 className="text-2xl font-bold">1. Assembly Counts</h2>
                  </div>
                  <div className="space-y-4">
                    {uniqueCategories.map(category => {
                      const categoryDishes = initialDishes.filter(d => d.category === category && mealTotals[d.id] > 0);
                      if (categoryDishes.length === 0) return null;
                      return (
                        <div key={category} className="bg-card border rounded-xl overflow-hidden shadow-sm print:border-gray-400">
                          <div className="bg-muted/40 px-4 py-2 border-b font-bold uppercase tracking-wider text-xs">{category}</div>
                          <ul className="divide-y">
                            {categoryDishes.map(dish => (
                              <li key={dish.id} className="p-4 flex flex-col gap-3">
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-lg">{dish.name}</span>
                                  <span className="text-2xl font-black bg-primary/10 text-primary px-4 py-1 rounded-lg print:bg-transparent print:text-black print:border-2 print:border-black">{mealTotals[dish.id]}</span>
                                </div>
                                {dish.ingredients && dish.ingredients.length > 0 && (
                                  <div className="flex flex-wrap gap-2">
                                    {dish.ingredients.map(ing => (
                                      <div key={ing.name} className="text-xs bg-muted border rounded-md px-2 py-1 font-medium">
                                        <span className="text-primary font-bold mr-1">{ing.amount * mealTotals[dish.id]}</span> {ing.unit} {ing.name}
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </li>
                            ))}
                          </ul>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <span className="text-2xl">⚖️</span>
                    <h2 className="text-2xl font-bold">2. Scaled Ingredients</h2>
                  </div>
                  <div className="bg-card border rounded-xl overflow-hidden shadow-sm print:border-gray-400">
                    <table className="w-full text-left">
                      <thead className="bg-muted/40 border-b">
                        <tr>
                          <th className="px-4 py-3 font-bold uppercase tracking-wider text-xs">Ingredient</th>
                          <th className="px-4 py-3 font-bold uppercase tracking-wider text-xs text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {Object.entries(ingredientTotals).map(([key, data]) => (
                          <tr key={key} className="hover:bg-muted/10">
                            <td className="px-4 py-3 font-medium">{key.split('|')[0]}</td>
                            <td className="px-4 py-3 text-right font-black text-lg">{data.amount} <span className="text-xs font-bold opacity-60">{data.unit}</span></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PACKING LABELS */}
          {activeTab === 'labels' && (
            <div className="labels-print-wrapper">
              <div className="labels-print-grid grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {labelsToPrint.map((labelInfo, index) => {
                  const color = divisionColors[labelInfo.child?.division] || { bg: '#f9f9f9', border: '#aaa' };
                  const dish = initialDishes.find(d => d.id === labelInfo.dishId);
                  const schoolName = (labelInfo.child?.schools as any)?.name || '';
                  const printDate = selectedDate ? new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
                  
                  return (
                    <div 
                      key={`${labelInfo.orderId}-${labelInfo.dishId}-${index}`} 
                      className="avery-label border-2 rounded-2xl p-3 bg-white shadow-sm flex flex-col gap-1 relative overflow-hidden"
                      style={{ borderColor: color.border, borderRightColor: color.border }}
                    >
                      {/* Screen-only: color strip */}
                      <div className="label-color-strip absolute top-0 right-0 bottom-0 w-3" style={{ backgroundColor: color.border }} />

                      {/* ROW 1: Name + Div badge on same line */}
                      <div className="label-row1 flex items-center gap-1.5 pr-3">
                        <span className="label-name font-black text-sm uppercase truncate flex-1 leading-none">{labelInfo.child?.name}</span>
                        <span 
                          className="label-div-badge text-[10px] font-black px-1.5 py-0.5 rounded border whitespace-nowrap shrink-0"
                          style={{ backgroundColor: color.bg, borderColor: color.border }}
                        >
                          {labelInfo.child?.division || 'N/A'}
                        </span>
                      </div>

                      {/* ROW 2: Delivery + Time */}
                      <div className="label-row2 flex justify-between text-[9px] font-semibold text-muted-foreground uppercase">
                        <span>{labelInfo.child?.delivery_location}</span>
                        <span className="font-black pr-3">{labelInfo.child?.lunch_time}</span>
                      </div>

                      {/* DIVIDER */}
                      <div className="label-divider border-t border-dashed my-0.5" style={{ borderColor: color.border }} />

                      {/* ROW 3: Dish name */}
                      <div className="label-dish flex items-center gap-1 font-bold text-sm overflow-hidden">
                        <span className="truncate">{dish?.name}</span>
                        {labelInfo.totalQuantity > 1 && (
                          <span className="text-[9px] text-muted-foreground font-bold shrink-0">({labelInfo.itemNumber}/{labelInfo.totalQuantity})</span>
                        )}
                      </div>

                      {/* ROW 4: School + Date */}
                      <div className="label-footer flex justify-between text-[8px] text-muted-foreground font-medium mt-auto">
                        <span className="label-school truncate max-w-[65%]">{schoolName}</span>
                        <span className="shrink-0 pr-3">{printDate}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}


          {/* TAB 3: MANIFEST */}
          {activeTab === 'manifest' && (
            <div className="space-y-6">
              {Object.keys(divisionColors).sort().map(div => {
                const color = divisionColors[div];
                const divOrders = orders.filter(o => o.children?.division === div);
                
                // Aggregate items for this division
                const divTotals: Record<string, number> = {};
                divOrders.forEach(o => {
                  o.order_items.forEach((item: any) => {
                    divTotals[item.dish_id] = (divTotals[item.dish_id] || 0) + item.quantity;
                  });
                });

                return (
                  <div key={div} className="border-2 rounded-2xl overflow-hidden shadow-sm print:border-black print:rounded-none">
                    <div 
                      className="px-6 py-3 flex justify-between items-center border-b-2"
                      style={{ backgroundColor: color.bg, borderColor: color.border }}
                    >
                      <h3 className="text-xl font-black">{div}</h3>
                      <div className="flex gap-4 text-sm font-bold">
                        <span>{divOrders.length} Students</span>
                        <span>{Object.values(divTotals).reduce((a, b) => a + b, 0)} Total Items</span>
                      </div>
                    </div>
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                       <table className="w-full text-left border-collapse">
                         <thead>
                           <tr className="text-[10px] font-black uppercase text-muted-foreground border-b">
                             <th className="pb-2">Dish</th>
                             <th className="pb-2 text-right w-20">Qty</th>
                           </tr>
                         </thead>
                         <tbody className="divide-y">
                           {Object.entries(divTotals).map(([dishId, qty]) => (
                             <tr key={dishId}>
                               <td className="py-2 font-bold">{initialDishes.find(d => d.id === dishId)?.name}</td>
                               <td className="py-2 text-right font-black text-lg">{qty}</td>
                             </tr>
                           ))}
                         </tbody>
                       </table>

                       <div className="bg-muted/20 rounded-xl p-4 space-y-2 border border-dashed">
                          <h4 className="text-[10px] font-black uppercase text-muted-foreground">Student List</h4>
                          <div className="text-xs grid grid-cols-2 gap-x-4 gap-y-1">
                             {divOrders.map(o => (
                               <div key={o.id} className="flex items-center gap-2">
                                  <div className="w-2 h-2 rounded-full bg-slate-300" />
                                  <span className="capitalize">{o.children?.name}</span>
                                </div>
                             ))}
                          </div>
                       </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
