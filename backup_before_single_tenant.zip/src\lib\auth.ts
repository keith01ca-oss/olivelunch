import { auth, currentUser } from '@clerk/nextjs/server';
import { cookies } from 'next/headers';
import { supabaseAdmin } from './supabase';

export type UserRole = 'parent' | 'admin' | 'kitchen';

export interface AuthContext {
  clerkUserId: string;
  role: UserRole;
  parentId: string | null;
}

/**
 * Validates the current Clerk session and resolves the Supabase parent_id.
 * This pattern MUST be used in all API routes accessing parent data.
 */
export async function getResolvedParent(): Promise<AuthContext | { error: string; status: number }> {
  // 1. Verify Clerk session
  const session = await auth();
  const clerkUserId = session.userId;
  
  if (!clerkUserId) {
    return { error: 'Unauthorized - No Clerk Session', status: 401 };
  }

  // 2. Extract Role (from Clerk Session Claims)
  const role = (session.sessionClaims?.metadata?.role as UserRole) || 'parent';

  // 3. Resolve parent_id from clerk_user_id
  const { data: parent, error } = await supabaseAdmin
    .from('parents')
    .select('id')
    .eq('clerk_user_id', clerkUserId)
    .single();

  if (error || !parent) {
    if (role === 'admin' || role === 'kitchen') {
      return { clerkUserId, role, parentId: null };
    }
    
    // Auto-provision the parent row on first login
    const user = await currentUser();
    if (!user) return { error: 'Clerk User details not found', status: 401 };

    const email = user.emailAddresses[0]?.emailAddress;
    const name = `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'New Parent';

    // Generate a unique referral code based on name + random suffix
    const namePart = name.replace(/[^a-zA-Z]/g, '').substring(0, 4).toUpperCase() || 'USER';
    const referralCode = `${namePart}${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    // Check if this new user was referred by someone (cookie set by /refer/[code])
    const refCode = cookies().get('olive_ref')?.value?.toUpperCase();
    const orgId = cookies().get('olive_org_id')?.value || null;
    let referredById: string | null = null;
    if (refCode) {
      const { data: referrer } = await supabaseAdmin
        .from('parents')
        .select('id')
        .eq('referral_code', refCode)
        .single();
      if (referrer) referredById = referrer.id;
    }

    const { data: newParent, error: insertError } = await supabaseAdmin
      .from('parents')
      .insert({
        clerk_user_id: clerkUserId,
        email: email,
        name: name,
        is_vip: false,
        referral_code: referralCode,
        referred_by: referredById,
        org_id: orgId
      })
      .select('id')
      .single();

    if (insertError || !newParent) {
      console.error('Failed to provision parent:', insertError);
      return { error: 'Failed to create parent profile', status: 500 };
    }

    return { clerkUserId, role, parentId: newParent.id };
  }

  return { clerkUserId, role, parentId: parent.id };
}

/**
 * Enforces that the user has the 'admin' role.
 */
export async function requireAdmin() {
  const context = await getResolvedParent();
  if ('error' in context) return context;
  if (context.role !== 'admin') return { error: 'Forbidden - Admins only', status: 403 };
  return context;
}

/**
 * Enforces that the user has the 'kitchen' role (or admin).
 */
export async function requireKitchen() {
  const context = await getResolvedParent();
  if ('error' in context) return context;
  if (context.role !== 'kitchen' && context.role !== 'admin') {
    return { error: 'Forbidden - Kitchen staff only', status: 403 };
  }
  return context;
}
