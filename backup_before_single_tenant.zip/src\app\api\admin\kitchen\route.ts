import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { cookies } from 'next/headers';

// GET /api/admin/kitchen?date=YYYY-MM-DD
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const date = searchParams.get('date');
  const orgId = cookies().get('olive_org_id')?.value;

  if (!date) {
    return NextResponse.json({ error: 'Date is required' }, { status: 400 });
  }

  try {
    // Fetch all paid orders for the specified date
    let query = supabaseAdmin
      .from('orders')
      .select(`
        id,
        order_date,
        order_items (
          dish_id,
          quantity,
          delivery_area
        ),
        children (
          name,
          division,
          delivery_location,
          lunch_time,
          schools (
            name
          )
        )
      `)
      .eq('order_date', date)
      .eq('status', 'paid');
    if (orgId) query = query.eq('org_id', orgId);
    const { data: orders, error } = await query;

    if (error) throw error;

    return NextResponse.json({ orders });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
