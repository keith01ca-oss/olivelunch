'use client';

import { useState, useMemo, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, addMonths, isBefore, startOfToday, addDays, startOfWeek, endOfWeek, eachWeekOfInterval } from 'date-fns';
import { ShoppingCart, Minus, Plus, Shuffle, Zap, Monitor, Smartphone, Trash2, Calendar, LayoutGrid } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface Dish {
  id: string;
  name: string;
  category: 'main' | 'side' | 'drink' | 'snack';
  price_regular: number;
  price_vip: number;
  is_active: boolean;
}

interface Props {
  childrenList: any[];
  dishes: Dish[];
  blockedDates: any[];
  prodDates: any[];
  dateWarnings: any[];
  isVip: boolean;
  initialChildId?: string;
  existingOrders?: any[];
  scheduledMenus?: any[];
  showWeekends?: boolean;
}

// Format: { 'YYYY-MM-DD': { dishId: number } }
type Cart = Record<string, Record<string, number>>;

// Compute available months (Current month + next 11 months)
function getAvailableMonths() {
  const months: Date[] = [];
  let current = startOfMonth(new Date());
  for (let i = 0; i < 12; i++) {
    months.push(current);
    current = addMonths(current, 1);
  }
  return months;
}

export default function MenuOrderClient({ childrenList, dishes, blockedDates, prodDates, dateWarnings, isVip, initialChildId, existingOrders = [], scheduledMenus = [], showWeekends = false }: Props) {
  const router = useRouter();

  const availableMonths = useMemo(() => getAvailableMonths(), []);

  const [selectedChildId, setSelectedChildId] = useState<string>(initialChildId || childrenList[0]?.id || '');
  const [currentMonthDate, setCurrentMonthDate] = useState<Date>(availableMonths[0]);

  
  const [cart, setCart] = useState<Cart>({});
  const [isLoaded, setIsLoaded] = useState(false);
  const [viewMode, setViewMode] = useState<'planner' | 'desktop' | 'mobile'>('desktop');
  const [expandedDays, setExpandedDays] = useState<Set<string>>(new Set());
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [selectedPlannerDishes, setSelectedPlannerDishes] = useState<string[]>([]);
  const [draggedDishId, setDraggedDishId] = useState<string | null>(null);

  // Device detection for default view
  useEffect(() => {
    const isMobile = window.matchMedia("(max-width: 768px)").matches;
    if (isMobile) {
      setViewMode('mobile');
    } else {
      // Default to planner or desktop on computer? User said "planner view before desktop view" 
      // and "default use desktop view on computer". 
      // Wait, "add a button for planner view before desktop view... default use desktop view on computer"
      setViewMode('desktop');
    }
  }, []);

  // Load Cart
  useEffect(() => {
    if (!selectedChildId) return;
    try {
      const saved = localStorage.getItem(`olive_cart_${selectedChildId}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Clean up cart on load: remove days that were PAID for, so the cart
        // doesn't show stale items after a successful checkout.
        // NOTE: existingOrders only contains 'paid' orders (pending/cancelled Stripe
        // sessions are NOT included), so cancelled checkouts won't wipe the cart.
        const childOrders = existingOrders.filter(o => o.child_id === selectedChildId);
        let hasChanges = false;
        childOrders.forEach(order => {
          if (parsed[order.order_date]) {
            delete parsed[order.order_date];
            hasChanges = true;
          }
        });
        setCart(parsed);
        if (hasChanges) localStorage.setItem(`olive_cart_${selectedChildId}`, JSON.stringify(parsed));
      }
      else setCart({});
    } catch (e) { console.error('Failed to load cart', e); }
    setIsLoaded(true);
  }, [selectedChildId, existingOrders]);

  // Save Cart
  useEffect(() => {
    if (!isLoaded || !selectedChildId) return;
    localStorage.setItem(`olive_cart_${selectedChildId}`, JSON.stringify(cart));
  }, [cart, isLoaded, selectedChildId]);

  const toggleExpanded = (dateKey: string) => {
    setExpandedDays(prev => {
      const next = new Set(prev);
      if (next.has(dateKey)) next.delete(dateKey);
      else next.add(dateKey);
      return next;
    });
  };

  const today = startOfToday();
  const cutoffTimePassed = new Date().getHours() >= 13;
  const minSelectableDate = cutoffTimePassed ? addDays(today, 2) : addDays(today, 1);

  const mainDishes = dishes.filter(d => d.category === 'main');
  const sideOptions = dishes.filter(d => d.category === 'side');
  const snackOptions = dishes.filter(d => d.category === 'snack');
  const drinkOptions = dishes.filter(d => d.category === 'drink');

  const isDateDisabled = (date: Date) => {
    const day = getDay(date);
    if (!showWeekends && (day === 0 || day === 6)) return true;
    if (isBefore(date, minSelectableDate)) return true;
    const dateKey = format(date, 'yyyy-MM-dd');
    if (blockedDates.some((b: any) => b.date === dateKey)) return true;
    return false;
  };

  const weeksInMonth = useMemo(() => {
    const monthStart = startOfMonth(currentMonthDate);
    const monthEnd = endOfMonth(currentMonthDate);
    const weeks: Date[][] = [];

    let current = startOfWeek(monthStart, { weekStartsOn: 1 });
    while (current.getTime() <= monthEnd.getTime()) {
      const weekDays: Date[] = [];
      const daysInWeek = showWeekends ? 7 : 5;
      for (let i = 0; i < daysInWeek; i++) {
        const day = addDays(current, i);
        if (day.getTime() >= monthStart.getTime() && day.getTime() <= monthEnd.getTime()) {
          weekDays.push(day);
        }
      }
      if (weekDays.length > 0) weeks.push(weekDays);
      current = addDays(current, 7);
    }
    return weeks;
  }, [currentMonthDate]);

  const updateQty = (dateKey: string, dishId: string, delta: number) => {
    setCart(prev => {
      const dayCart = { ...(prev[dateKey] || {}) };
      const cur = dayCart[dishId] || 0;
      const next = Math.max(0, cur + delta);
      if (next === 0) delete dayCart[dishId];
      else dayCart[dishId] = next;
      if (Object.keys(dayCart).length === 0) {
        const updated = { ...prev };
        delete updated[dateKey];
        return updated;
      }
      return { ...prev, [dateKey]: dayCart };
    });
  };

  const getScheduledDishesForCategory = (dateKey: string, category: string) => {
    const scheduled = scheduledMenus.filter(m => m.date === dateKey);
    const categoryDishes = dishes.filter(d => d.category === category);
    
    return scheduled
      .map(s => categoryDishes.find(d => d.id === s.dish_id))
      .filter(Boolean) as Dish[];
  };

  // Get unique dishes scheduled for the current month (for sidebar)
  const plannerMonthDishes = useMemo(() => {
    const monthStr = format(currentMonthDate, 'yyyy-MM');
    const scheduledThisMonth = scheduledMenus.filter(m => m.date.startsWith(monthStr));
    const seenIds = new Set<string>();
    const result: Dish[] = [];
    scheduledThisMonth.forEach(s => {
      if (!seenIds.has(s.dish_id)) {
        const dish = dishes.find(d => d.id === s.dish_id);
        if (dish) { seenIds.add(s.dish_id); result.push(dish); }
      }
    });
    return result;
  }, [scheduledMenus, dishes, currentMonthDate]);

  const plannerCategories: Array<'main' | 'side' | 'snack' | 'drink'> = ['main', 'side', 'snack', 'drink'];

  const togglePlannerDish = (dishId: string) => {
    setSelectedPlannerDishes(prev =>
      prev.includes(dishId) ? prev.filter(id => id !== dishId) : [...prev, dishId]
    );
  };

  const handleAddSelectedToMonth = () => {
    if (selectedPlannerDishes.length === 0) return;
    const monthStart = startOfMonth(currentMonthDate);
    const monthEnd = endOfMonth(currentMonthDate);
    const allDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
    setCart(prev => {
      const updated = { ...prev };
      allDays.forEach(day => {
        if (isDateDisabled(day)) return;
        const dateKey = format(day, 'yyyy-MM-dd');
        // Only add to days where admin has scheduled any content
        const hasScheduled = scheduledMenus.some(m => m.date === dateKey);
        if (!hasScheduled) return;
        const dayCart = { ...(updated[dateKey] || {}) };
        // Add ALL selected dishes to every valid day (qty 1, or increment if already in cart)
        selectedPlannerDishes.forEach(dishId => {
          dayCart[dishId] = (dayCart[dishId] || 0) + 1;
        });
        updated[dateKey] = dayCart;
      });
      return updated;
    });
    setSelectedPlannerDishes([]);
  };

  const handleDropOnDay = (dateKey: string, dishId: string) => {
    if (!dishId) return;
    // Only allow drop if admin scheduled this dish for this date
    const isScheduledForDay = scheduledMenus.some(m => m.date === dateKey && m.dish_id === dishId);
    if (!isScheduledForDay) return;
    setCart(prev => {
      const dayCart = { ...(prev[dateKey] || {}) };
      dayCart[dishId] = (dayCart[dishId] || 0) + 1;
      return { ...prev, [dateKey]: dayCart };
    });
  };

  const toggleDay = (date: Date) => {
    if (isDateDisabled(date)) return;
    const dateKey = format(date, 'yyyy-MM-dd');
    const dayMains = getScheduledDishesForCategory(dateKey, 'main');
    const daySides = getScheduledDishesForCategory(dateKey, 'side');
    const daySnacks = getScheduledDishesForCategory(dateKey, 'snack');
    const dayDrinks = getScheduledDishesForCategory(dateKey, 'drink');
    
    const firstDish = dayMains[0] || daySides[0] || daySnacks[0] || dayDrinks[0];
    if (!firstDish) return;

    setCart(prev => {
      if (prev[dateKey]) {
        const updated = { ...prev };
        delete updated[dateKey];
        return updated;
      } else {
        return { ...prev, [dateKey]: { [firstDish.id]: 1 } };
      }
    });
  };

  const orderWeek = (days: Date[]) => {
    setCart(prev => {
      const updated = { ...prev };
      days.forEach(day => {
        if (!isDateDisabled(day)) {
          const key = format(day, 'yyyy-MM-dd');
          const dayMains = getScheduledDishesForCategory(key, 'main');
          const daySides = getScheduledDishesForCategory(key, 'side');
          const daySnacks = getScheduledDishesForCategory(key, 'snack');
          const dayDrinks = getScheduledDishesForCategory(key, 'drink');
          const firstDish = dayMains[0] || daySides[0] || daySnacks[0] || dayDrinks[0];
          
          if (firstDish && !updated[key]) {
            updated[key] = { [firstDish.id]: 1 };
          }
        }
      });
      return updated;
    });
  };

  const autoFillMonth = () => {
    const monthStart = startOfMonth(currentMonthDate);
    const monthEnd = endOfMonth(currentMonthDate);
    const allDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
    setCart(prev => {
      const updated = { ...prev };
      allDays.forEach(day => {
        if (!isDateDisabled(day)) {
          const key = format(day, 'yyyy-MM-dd');
          const dayMains = getScheduledDishesForCategory(key, 'main');
          const daySides = getScheduledDishesForCategory(key, 'side');
          const daySnacks = getScheduledDishesForCategory(key, 'snack');
          const dayDrinks = getScheduledDishesForCategory(key, 'drink');
          const firstDish = dayMains[0] || daySides[0] || daySnacks[0] || dayDrinks[0];
          
          if (firstDish && !updated[key]) {
            updated[key] = { [firstDish.id]: 1 };
          }
        }
      });
      return updated;
    });
  };

  const randomizeSides = () => {
    if (sideOptions.length === 0) return;
    setCart(prev => {
      const updated: Cart = {};
      Object.keys(prev).forEach(dateKey => {
        const dayCart = { ...prev[dateKey] };
        
        // Remove ALL existing sides first (we need to find which items in cart are sides)
        const daySides = getScheduledDishesForCategory(dateKey, 'side');
        sideOptions.forEach(s => delete dayCart[s.id]);
        
        const randomSide = daySides[Math.floor(Math.random() * daySides.length)];
        if (randomSide) dayCart[randomSide.id] = 1;
        updated[dateKey] = dayCart;
      });
      return updated;
    });
  };

  const randomizeWeekSides = (days: Date[]) => {
    if (sideOptions.length === 0) return;
    setCart(prev => {
      const updated = { ...prev };
      days.forEach(day => {
        if (isDateDisabled(day)) return;
        const dateKey = format(day, 'yyyy-MM-dd');
        const dayMains = getScheduledDishesForCategory(dateKey, 'main');
        const daySides = getScheduledDishesForCategory(dateKey, 'side');
        const daySnacks = getScheduledDishesForCategory(dateKey, 'snack');
        const dayDrinks = getScheduledDishesForCategory(dateKey, 'drink');
        const firstDish = dayMains[0] || daySides[0] || daySnacks[0] || dayDrinks[0];
        
        // Ensure day exists in cart (implicitly selects it)
        const dayCart = { ...(prev[dateKey] || (firstDish ? { [firstDish.id]: 1 } : {})) };
        
        // Remove existing sides
        sideOptions.forEach(s => delete dayCart[s.id]);
        
        // Add random side from available sides for THIS day
        const randomSide = daySides[Math.floor(Math.random() * daySides.length)];
        if (randomSide) dayCart[randomSide.id] = 1;
        
        updated[dateKey] = dayCart;
      });
      return updated;
    });
  };

  // Totals
  let totalItems = 0;
  let totalDays = 0;
  let totalPrice = 0;
  Object.keys(cart).forEach(dateKey => {
    totalDays++;
    Object.keys(cart[dateKey]).forEach(dishId => {
      const qty = cart[dateKey][dishId];
      const dish = dishes.find(d => d.id === dishId);
      if (dish) {
        totalPrice += (isVip ? dish.price_vip : dish.price_regular) * qty;
        totalItems += qty;
      }
    });
  });

  const handleCheckout = async () => {
    if (totalItems === 0 || isCheckingOut) return;
    setIsCheckingOut(true);
    try {
      const ordersArray = Object.keys(cart).map(date => ({
        child_id: selectedChildId,
        order_date: date,
        items: Object.keys(cart[date]).map(dishId => ({
          dish_id: dishId,
          quantity: cart[date][dishId],
        }))
      }));

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orders: ordersArray })
      });
      const data = await res.json();

      if (data.error) { alert(data.error); return; }
      if (data.stripe_url) window.location.href = data.stripe_url;
      else if (data.success) router.push('/dashboard?success=true');
    } catch (err) {
      alert("Something went wrong. Please try again.");
    } finally {
      setIsCheckingOut(false);
    }
  };

  const DayCard = ({ day }: { day: Date }) => {
    const dateKey = format(day, 'yyyy-MM-dd');
    const isDisabled = isDateDisabled(day);
    const isSelected = !!cart[dateKey];
    const dayCart = cart[dateKey] || {};
    const isMobile = viewMode === 'mobile';
    const isExpanded = !isMobile || expandedDays.has(dateKey);

    // Find a blocked reason for this specific date
    const blockedInfo = blockedDates.find((b: any) => b.date === dateKey);
    const prodInfo = prodDates.find((p: any) => dateKey >= p.start_date && dateKey <= p.end_date);
    const blockReason = blockedInfo?.reason || prodInfo?.message || null;

    // Find a non-blocking warning for this date
    const warningInfo = dateWarnings.find((w: any) => w.date === dateKey);

    // Summary line for mobile collapsed state
    const selectedItemCount = Object.values(dayCart).reduce((a, b) => a + b, 0);
    // Existing Order lookup (may have multiple orders for the same day)
    const dayOrders = existingOrders.filter(o => o.child_id === selectedChildId && o.order_date === dateKey);
    const hasExisting = dayOrders.length > 0;

    return (
      <div className={`rounded-xl border-2 transition-all flex flex-col ${
        isDisabled ? 'opacity-40 bg-muted/30 border-border cursor-not-allowed' :
        isSelected ? 'border-primary bg-primary/5 shadow-sm' : 
        hasExisting ? 'border-green-400 bg-green-50/30' : 'border-border bg-card hover:border-primary/40'
      }`}>
        {/* Day Header - always visible */}
        <div
          className={`flex items-center justify-between p-3 rounded-t-xl font-bold text-base cursor-pointer ${
            isSelected ? 'bg-primary/10' : hasExisting ? 'bg-green-100/50' : ''
          } ${isMobile ? 'rounded-b-xl' : ''} ${isMobile && isExpanded ? 'rounded-b-none border-b' : ''}`}
          onClick={() => {
            if (isDisabled) return;
            if (isMobile) {
              toggleExpanded(dateKey);
            } else {
              toggleDay(day);
            }
          }}
        >
          <div className="flex items-center gap-3 min-w-0">
            <span className="text-foreground shrink-0">{format(day, 'd EEE')}</span>
            {/* Mobile collapsed summary */}
            {isMobile && !isExpanded && isSelected && (() => {
              const mainInCart = getScheduledDishesForCategory(dateKey, 'main').find(m => dayCart[m.id]);
              return (
                <span className="text-xs text-muted-foreground truncate">
                  {mainInCart ? mainInCart.name : ''}{selectedItemCount > 1 ? ` + ${selectedItemCount - 1} more` : ''}
                </span>
              );
            })()}
            {isMobile && !isExpanded && !isSelected && hasExisting && (
              <span className="text-xs text-green-700 font-bold truncate flex-1 min-w-0">Already ordered</span>
            )}
            {isMobile && !isExpanded && !isSelected && !hasExisting && blockReason && (
              <span className="text-xs text-red-600 font-bold truncate flex-1 min-w-0">🚫 {blockReason}</span>
            )}
            {isMobile && !isExpanded && !isSelected && !hasExisting && !blockReason && warningInfo && (
              <span className="text-xs text-amber-700 font-bold truncate flex-1 min-w-0">⚠️ {warningInfo.message}</span>
            )}
            {isMobile && !isExpanded && !isSelected && !isDisabled && !hasExisting && !blockReason && !warningInfo && (
              <span className="text-xs text-muted-foreground">Tap to see menu</span>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {isMobile && (
              <span className="text-xs text-muted-foreground">{isExpanded ? '▲' : '▼'}</span>
            )}
            <input
              type="checkbox"
              checked={isSelected}
              onChange={(e) => {
                e.stopPropagation();
                if (isDisabled) return;
                toggleDay(day);
                // On mobile, also expand the card when checking
                if (isMobile && !isExpanded) toggleExpanded(dateKey);
              }}
              disabled={isDisabled}
              className="w-5 h-5 accent-primary cursor-pointer"
              onClick={e => e.stopPropagation()}
            />
          </div>
        </div>

        {isExpanded && (
        <div className={`p-3 space-y-3 flex-1 flex flex-col ${isDisabled && !blockReason ? 'pointer-events-none opacity-50' : ''}`}>
            
            {/* Blocked Date Notice */}
            {blockReason && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-sm flex items-start gap-2">
                <span className="text-base shrink-0">🚫</span>
                <div>
                  <p className="font-bold">No Ordering Available</p>
                  <p className="text-xs mt-0.5">{blockReason}</p>
                </div>
              </div>
            )}

            {/* Date Warning Banner (amber, ordering still allowed) */}
            {!blockReason && warningInfo && (
              <div className="bg-amber-50 border border-amber-300 text-amber-800 p-3 rounded-lg text-sm flex items-start gap-2">
                <span className="text-base shrink-0">⚠️</span>
                <div>
                  <p className="font-bold">Notice</p>
                  <p className="text-xs mt-0.5">{warningInfo.message}</p>
                </div>
              </div>
            )}

            {/* Existing Order Warning */}
            {hasExisting && (
              <div className="bg-green-100 border border-green-200 text-green-800 p-2 rounded-lg text-xs">
                <p className="font-bold mb-1">Already ordered:</p>
                <ul className="list-disc pl-4 space-y-0.5">
                  {dayOrders.flatMap((o: any) => o.order_items).map((item: any) => (
                    <li key={item.id}>{item.quantity}x {item.dishes?.name}</li>
                  ))}
                </ul>
                {isSelected && (
                  <p className="mt-2 text-amber-700 font-bold bg-amber-100 p-1 rounded">⚠️ You are adding an ADDITIONAL order for this day.</p>
                )}
              </div>
            )}

            {/* Main Dishes */}
            {!blockReason && (() => {
              const currentDayMains = getScheduledDishesForCategory(dateKey, 'main');
              if (currentDayMains.length === 0) return null;
              
              return (
                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider text-center flex items-center gap-2 before:h-px before:flex-1 before:bg-border after:h-px after:flex-1 after:bg-border">
                    Main Dishes
                  </p>
                  {currentDayMains.map(item => (
                    <div key={item.id} className="flex items-center gap-1.5">
                      <button onClick={() => updateQty(dateKey, item.id, -1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-5 text-center text-sm font-bold shrink-0">{dayCart[item.id] || 0}</span>
                      <button onClick={() => updateQty(dateKey, item.id, 1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-sm truncate flex-1 min-w-0" title={item.name}>{item.name}</span>
                      <span className="text-xs text-primary font-bold shrink-0">${(isVip ? item.price_vip : item.price_regular).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              );
            })()}
            
            {/* Sides */}
            {!blockReason && (() => {
              const currentDaySides = getScheduledDishesForCategory(dateKey, 'side');
              if (currentDaySides.length === 0) return null;
              
              return (
                <div className="border-t pt-2 mt-2 space-y-1.5">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider text-center flex items-center gap-2 before:h-px before:flex-1 before:bg-border after:h-px after:flex-1 after:bg-border">
                    Sides
                  </p>
                {currentDaySides.map(item => (
                  <div key={item.id} className="flex items-center gap-1.5">
                    <button onClick={() => updateQty(dateKey, item.id, -1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-5 text-center text-sm font-bold shrink-0">{dayCart[item.id] || 0}</span>
                    <button onClick={() => updateQty(dateKey, item.id, 1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-sm truncate flex-1 min-w-0" title={item.name}>{item.name}</span>
                    <span className="text-xs text-primary font-bold shrink-0">${(isVip ? item.price_vip : item.price_regular).toFixed(2)}</span>
                  </div>
                ))}
                </div>
              );
            })()}

            {/* Snacks */}
            {!blockReason && (() => {
              const currentDaySnacks = getScheduledDishesForCategory(dateKey, 'snack');
              if (currentDaySnacks.length === 0) return null;
              
              return (
                <div className="border-t pt-2 mt-2 space-y-1.5">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider text-center flex items-center gap-2 before:h-px before:flex-1 before:bg-border after:h-px after:flex-1 after:bg-border">
                    Snacks
                  </p>
                  {currentDaySnacks.map(item => (
                  <div key={item.id} className="flex items-center gap-1.5">
                    <button onClick={() => updateQty(dateKey, item.id, -1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-5 text-center text-sm font-bold shrink-0">{dayCart[item.id] || 0}</span>
                    <button onClick={() => updateQty(dateKey, item.id, 1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-sm truncate flex-1 min-w-0" title={item.name}>{item.name}</span>
                    <span className="text-xs text-primary font-bold shrink-0">${(isVip ? item.price_vip : item.price_regular).toFixed(2)}</span>
                  </div>
                ))}
                </div>
              );
            })()}

            {/* Drinks */}
            {!blockReason && (() => {
              const currentDayDrinks = getScheduledDishesForCategory(dateKey, 'drink');
              if (currentDayDrinks.length === 0) return null;
              
              return (
                <div className="border-t pt-2 mt-2 space-y-1.5">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider text-center flex items-center gap-2 before:h-px before:flex-1 before:bg-border after:h-px after:flex-1 after:bg-border">
                    Drinks
                  </p>
                  {currentDayDrinks.map(item => (
                  <div key={item.id} className="flex items-center gap-1.5">
                    <button onClick={() => updateQty(dateKey, item.id, -1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-5 text-center text-sm font-bold shrink-0">{dayCart[item.id] || 0}</span>
                    <button onClick={() => updateQty(dateKey, item.id, 1)} className="w-6 h-6 rounded bg-secondary flex items-center justify-center hover:bg-primary/20 shrink-0">
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-sm truncate flex-1 min-w-0" title={item.name}>{item.name}</span>
                    <span className="text-xs text-primary font-bold shrink-0">${(isVip ? item.price_vip : item.price_regular).toFixed(2)}</span>
                  </div>
                ))}
                </div>
              );
            })()}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`flex flex-col h-full ${viewMode === 'mobile' ? 'max-w-sm mx-auto' : 'w-full'} transition-all duration-300`}>
      
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        {/* Child Selector */}
        <select
          value={selectedChildId}
          onChange={(e) => setSelectedChildId(e.target.value)}
          className="h-9 rounded-lg border border-input bg-card px-3 text-sm font-medium shadow-sm focus:ring-1 focus:ring-primary"
        >
          {childrenList.map(c => (
            <option key={c.id} value={c.id}>{c.name} ({c.division})</option>
          ))}
        </select>

        {/* View Toggle */}
        <div className="flex items-center gap-2 bg-muted rounded-lg p-1 self-start sm:self-auto">
          <button
            onClick={() => setViewMode('planner')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              viewMode === 'planner' ? 'bg-card shadow-sm text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" /> Planner View
          </button>
          <button
            onClick={() => setViewMode('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              viewMode === 'desktop' ? 'bg-card shadow-sm text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" /> Desktop View
          </button>
          <button
            onClick={() => setViewMode('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              viewMode === 'mobile' ? 'bg-card shadow-sm text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" /> Mobile View
          </button>
        </div>
      </div>

      {/* Month Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {availableMonths.map(month => (
          <button
            key={month.toISOString()}
            onClick={() => setCurrentMonthDate(month)}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold border transition-all ${
              month.getMonth() === currentMonthDate.getMonth() && month.getFullYear() === currentMonthDate.getFullYear()
                ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                : 'bg-card border-border text-foreground hover:border-primary/50'
            }`}
          >
            {format(month, 'MMM')}
          </button>
        ))}
      </div>

      {/* Month Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-extrabold tracking-tight">
          {format(currentMonthDate, 'MMMM yyyy')}
        </h2>
        <div className="flex items-center gap-2">
          <button
            onClick={autoFillMonth}
            className="flex items-center gap-1.5 text-xs font-semibold border border-border bg-card rounded-lg px-3 py-1.5 hover:border-primary hover:text-primary transition-colors shadow-sm"
          >
            <Zap className="w-3.5 h-3.5" /> Auto-fill month
          </button>
          <button
            onClick={randomizeSides}
            className="flex items-center gap-1.5 text-xs font-semibold border border-border bg-card rounded-lg px-3 py-1.5 hover:border-primary hover:text-primary transition-colors shadow-sm"
          >
            <Shuffle className="w-3.5 h-3.5" /> Randomize sides
          </button>
        </div>
      </div>

      {/* Weeks & Calendar */}
      <div className="space-y-6 pb-12">
        {viewMode === 'planner' ? (
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Planner Sidebar */}
            <div className="w-full lg:w-64 shrink-0 space-y-3">
              {/* Bulk add panel */}
              {selectedPlannerDishes.length > 0 && (
                <div className="bg-primary/5 border border-primary/20 rounded-2xl p-4 animate-pulse-once">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-primary uppercase tracking-wider">Bulk Add</span>
                    <button onClick={() => setSelectedPlannerDishes([])} className="text-muted-foreground hover:text-foreground text-lg leading-none">×</button>
                  </div>
                  <p className="text-sm font-bold mb-1">{selectedPlannerDishes.length} selected</p>
                  <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                    {selectedPlannerDishes.map(id => dishes.find(d => d.id === id)?.name).filter(Boolean).join(', ')}
                  </p>
                  <button
                    onClick={handleAddSelectedToMonth}
                    className="w-full bg-primary text-primary-foreground font-bold py-2 px-3 rounded-xl text-sm hover:bg-primary/90 transition-colors shadow-sm"
                  >
                    + Add to Entire Month
                  </button>
                  <p className="text-[10px] text-muted-foreground mt-2 text-center">Only adds to days where admin scheduled this dish.</p>
                </div>
              )}

              {/* Dishes list */}
              <div className="bg-card border rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-sm">Available Dishes</h3>
                  <span className="text-[10px] text-muted-foreground">Click or drag to calendar</span>
                </div>

                {/* Remove All/Selected for Month */}
                {(() => {
                  const monthStr = format(currentMonthDate, 'yyyy-MM');
                  const monthCartDays = Object.keys(cart).filter(k => k.startsWith(monthStr));
                  if (monthCartDays.length === 0) return null;
                  
                  const isFiltered = selectedPlannerDishes.length > 0;

                  return (
                    <button
                      onClick={() => {
                        const monthStr2 = format(currentMonthDate, 'yyyy-MM');
                        setCart(prev => {
                          const updated = { ...prev };
                          Object.keys(updated).forEach(k => { 
                            if (k.startsWith(monthStr2)) {
                              if (isFiltered) {
                                // Only remove selected dishes from this day's cart
                                const dayCart = { ...updated[k] };
                                selectedPlannerDishes.forEach(id => delete dayCart[id]);
                                if (Object.keys(dayCart).length === 0) delete updated[k];
                                else updated[k] = dayCart;
                              } else {
                                // Remove entire day
                                delete updated[k];
                              }
                            }
                          });
                          return updated;
                        });
                        if (isFiltered) setSelectedPlannerDishes([]);
                      }}
                      className={`w-full mb-3 flex items-center justify-center gap-1.5 text-xs font-bold border rounded-xl py-2 px-3 transition-colors ${
                        isFiltered 
                        ? 'text-red-700 border-red-300 bg-red-100 hover:bg-red-200' 
                        : 'text-red-600 border-red-200 bg-red-50 hover:bg-red-100'
                      }`}
                    >
                      <Trash2 className="w-3.5 h-3.5" /> 
                      {isFiltered ? `Remove Selected for ${format(currentMonthDate, 'MMM')}` : `Remove All for ${format(currentMonthDate, 'MMM')}`}
                    </button>
                  );
                })()}

                {plannerMonthDishes.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">No dishes scheduled for this month.</p>
                ) : (
                  <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
                    {plannerCategories.map(cat => {
                      const catDishes = plannerMonthDishes.filter(d => d.category === cat);
                      if (catDishes.length === 0) return null;
                      return (
                        <div key={cat}>
                          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground border-b pb-1 mb-2">{cat}</p>
                          <div className="space-y-1.5">
                            {catDishes.map(dish => {
                              const isSelected = selectedPlannerDishes.includes(dish.id);
                              return (
                                <div
                                  key={dish.id}
                                  draggable
                                  onDragStart={() => setDraggedDishId(dish.id)}
                                  onDragEnd={() => setDraggedDishId(null)}
                                  onClick={() => togglePlannerDish(dish.id)}
                                  className={`flex items-center gap-2 border rounded-xl p-2.5 cursor-pointer transition-all select-none ${
                                    isSelected
                                      ? 'bg-primary/10 border-primary ring-1 ring-primary'
                                      : 'bg-background hover:border-primary/50 hover:shadow-sm'
                                  }`}
                                >
                                  <div className="cursor-grab text-muted-foreground">⠿</div>
                                  <div className="flex-1 min-w-0">
                                    <p className={`text-sm font-bold truncate ${isSelected ? 'text-primary' : ''}`}>{dish.name}</p>
                                    <p className="text-xs text-muted-foreground">${(isVip ? dish.price_vip : dish.price_regular).toFixed(2)}</p>
                                  </div>
                                  {isSelected && <span className="text-primary text-base">✓</span>}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Planner Calendar */}
            <div className="flex-1 bg-card border rounded-2xl overflow-hidden shadow-sm min-w-0">
              {/* Days Header */}
              <div className={`grid ${showWeekends ? 'grid-cols-7' : 'grid-cols-5'} border-b bg-muted/20`}>
                {(showWeekends ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']).map(day => (
                  <div key={day} className="py-2 text-center text-xs font-bold text-muted-foreground uppercase tracking-wider">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className={`grid ${showWeekends ? 'grid-cols-7' : 'grid-cols-5'}`}>
                {weeksInMonth.map((week, wi) => (
                  <div key={wi} className="contents">
                    {/* Fill empty start slots */}
                    {wi === 0 && week[0] && (getDay(week[0]) === 0 ? 6 : getDay(week[0]) - 1) > 0 &&
                      Array.from({ length: getDay(week[0]) === 0 ? 6 : getDay(week[0]) - 1 }).map((_, i) => (
                        <div key={`fill-${i}`} className="border-b border-r bg-muted/5 min-h-[110px]" />
                      ))
                    }

                    {week.map(day => {
                      const dateKey = format(day, 'yyyy-MM-dd');
                      const isDisabled = isDateDisabled(day);
                      const dayCart = cart[dateKey] || {};
                      const cartEntries = Object.entries(dayCart);
                      const hasScheduled = scheduledMenus.some(m => m.date === dateKey);
                      const existingOrder = existingOrders.find(o => o.child_id === selectedChildId && o.order_date === dateKey);
                      // Blocked date detection (same as DayCard)
                      const blockedInfo = blockedDates.find((b: any) => b.date === dateKey);
                      const prodInfo = prodDates.find((p: any) => dateKey >= p.start_date && dateKey <= p.end_date);
                      const blockReason = blockedInfo?.reason || prodInfo?.message || null;
                      const isBlocked = !!blockReason;

                      return (
                        <div
                          key={dateKey}
                          className={`border-b border-r p-1.5 min-h-[110px] transition-all relative ${
                            isBlocked ? 'bg-red-50/60 opacity-60 cursor-not-allowed' :
                            isDisabled ? 'bg-muted/10 opacity-40 cursor-not-allowed' :
                            draggedDishId && hasScheduled ? 'hover:bg-primary/5 hover:ring-2 hover:ring-primary hover:ring-inset cursor-copy' :
                            existingOrder ? 'bg-green-50/30' :
                            cartEntries.length > 0 ? 'bg-primary/5' : ''
                          }`}
                          onDragOver={e => { if (!isDisabled && !isBlocked && hasScheduled) e.preventDefault(); }}
                          onDrop={e => {
                            e.preventDefault();
                            if (!isDisabled && !isBlocked && draggedDishId) handleDropOnDay(dateKey, draggedDishId);
                          }}
                        >
                          {/* Date number */}
                          <div className="flex items-center justify-between mb-1">
                            <span className={`text-[11px] font-bold ${
                              isBlocked ? 'text-red-500' :
                              isDisabled ? 'text-muted-foreground' :
                              cartEntries.length > 0 ? 'text-primary' : 'text-muted-foreground'
                            }`}>{format(day, 'd')}</span>
                            {existingOrder && !isBlocked && <span className="text-[9px] font-bold text-green-700 bg-green-100 rounded px-1">Ordered</span>}
                          </div>

                          {/* Blocked reason */}
                          {isBlocked && (
                            <div className="flex items-center gap-1 mt-1">
                              <span className="text-[10px]">🚫</span>
                              <span className="text-[10px] font-semibold text-red-600 truncate">{blockReason}</span>
                            </div>
                          )}

                          {/* Cart items in this day */}
                          {!isBlocked && (
                            <div className="space-y-0.5">
                              {cartEntries.map(([dishId, qty]) => {
                                const dish = dishes.find(d => d.id === dishId);
                                if (!dish) return null;
                                return (
                                  <div key={dishId} className="flex items-center gap-1 group">
                                    <span className={`text-[10px] leading-tight truncate flex-1 font-medium rounded px-1 ${
                                      dish.category === 'main' ? 'bg-primary/10 text-primary' :
                                      dish.category === 'side' ? 'bg-amber-100 text-amber-800' :
                                      dish.category === 'drink' ? 'bg-blue-100 text-blue-800' :
                                      'bg-purple-100 text-purple-800'
                                    }`}>
                                      {qty > 1 && <span className="font-bold">{qty}×</span>} {dish.name}
                                    </span>
                                    <button
                                      onClick={() => updateQty(dateKey, dishId, -1)}
                                      className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 text-xs leading-none shrink-0 transition-opacity"
                                    >×</button>
                                  </div>
                                );
                              })}
                            </div>
                          )}

                          {/* Drop hint */}
                          {!isDisabled && !isBlocked && hasScheduled && cartEntries.length === 0 && !existingOrder && (
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity pointer-events-none">
                              <Plus className="w-5 h-5 text-primary/30" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          weeksInMonth.map((week, wi) => {
            const weekStart = week[0];
            const weekEnd = week[week.length - 1];
            return (
              <div key={wi} className="rounded-2xl border bg-card/60 overflow-hidden">
                {/* Week Header */}
                <div className="flex items-center justify-between px-4 py-2 bg-muted/60 border-b">
                  <h3 className="font-bold text-sm text-foreground">
                    Week {wi + 1}: {format(weekStart, 'MMM d')} - {format(weekEnd, 'd')}
                  </h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => randomizeWeekSides(week)}
                      className="flex items-center gap-1.5 text-xs font-bold bg-background border px-3 py-1 rounded-full hover:bg-primary/10 hover:text-primary transition-colors shadow-sm"
                    >
                      <Shuffle className="w-3 h-3" /> Random Sides
                    </button>
                    <button
                      onClick={() => orderWeek(week)}
                      className="text-xs font-bold bg-primary text-primary-foreground px-3 py-1 rounded-full hover:bg-primary/90 transition-colors shadow-sm"
                    >
                      Order this week
                    </button>
                  </div>
                </div>

                {/* Day Cards */}
                <div className={`flex gap-2 p-3 ${viewMode === 'mobile' ? 'flex-col' : 'flex-row'}`}>
                  {/* Fill missing days if week doesn't start on Mon */}
                  {viewMode === 'desktop' && week[0] && (getDay(week[0]) === 0 ? 6 : getDay(week[0]) - 1) > 0 &&
                    Array.from({ length: getDay(week[0]) === 0 ? 6 : getDay(week[0]) - 1 }).map((_, i) => (
                      <div key={`empty-${i}`} className="flex-1 min-w-0 rounded-xl border-2 border-dashed border-border/40 opacity-30 h-20" />
                    ))
                  }
                  {week.map(day => (
                    <div key={day.toISOString()} className={viewMode === 'desktop' ? 'flex-1 min-w-0' : 'w-full'}>
                      <DayCard day={day} />
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bottom Month Tabs */}
      <div className="flex flex-wrap gap-2 mb-32 border-t pt-8">
        {availableMonths.map(month => (
          <button
            key={month.toISOString()}
            onClick={() => {
              setCurrentMonthDate(month);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold border transition-all ${
              month.getMonth() === currentMonthDate.getMonth() && month.getFullYear() === currentMonthDate.getFullYear()
                ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                : 'bg-card border-border text-foreground hover:border-primary/50'
            }`}
          >
            {format(month, 'MMM')}
          </button>
        ))}
      </div>

      {/* Sticky Bottom Cart */}
      <div className="fixed bottom-[4.5rem] md:bottom-0 left-0 right-0 z-50 pointer-events-none">
        <div className="container max-w-5xl mx-auto px-4 pb-4 pointer-events-none">
          <div className={`bg-foreground text-background rounded-2xl shadow-2xl overflow-hidden pointer-events-auto transition-all duration-300 ${totalItems === 0 ? 'opacity-0 translate-y-4 pointer-events-none' : 'opacity-100 translate-y-0'}`}>
            <div className="flex items-center justify-between px-6 py-4">
              <div className="flex items-center gap-3">
                <div className="bg-primary p-2 rounded-xl">
                  <ShoppingCart className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <p className="font-bold text-lg">{totalDays} day{totalDays !== 1 ? 's' : ''} selected</p>
                  <p className="text-sm opacity-70">{totalItems} total item{totalItems !== 1 ? 's' : ''}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 sm:gap-4">
                <button
                  onClick={() => setCart({})}
                  className="text-sm font-semibold flex items-center gap-1.5 opacity-70 hover:opacity-100 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4 hidden sm:block" /> Clear
                </button>
                <div className="w-px h-6 bg-background/20 hidden sm:block"></div>
                <p className="text-xl font-extrabold">${totalPrice.toFixed(2)}</p>
                <button
                  onClick={handleCheckout}
                  disabled={isCheckingOut}
                  className="bg-primary text-primary-foreground font-bold px-6 py-2.5 rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-60 shadow-lg"
                >
                  {isCheckingOut ? 'Redirecting...' : 'Add to Cart →'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
