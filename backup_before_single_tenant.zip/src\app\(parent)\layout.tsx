import { ParentNavbar } from '@/components/layout/ParentNavbar';
import { getResolvedParent } from '@/lib/auth';
import { auth } from '@clerk/nextjs/server';

export default async function ParentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const authContext = await getResolvedParent();
  const { orgId, orgRole } = auth();
  let isAdmin = false;

  if (!('error' in authContext)) {
    // 1. Check if Super Admin (Platform Owner)
    const allowedIds = (process.env.ADMIN_CLERK_USER_IDS || '').split(',').map(id => id.trim()).filter(Boolean);
    if (allowedIds.includes(authContext.clerkUserId)) {
      isAdmin = true;
    }
    
    // 2. Check if B2B Org Admin/Staff (They belong to a Clerk Organization)
    if (orgId && (orgRole === 'org:admin' || orgRole === 'org:member')) {
      isAdmin = true;
    }
  }

  return (
    <div className="min-h-screen bg-gray-50/50 flex flex-col">
      <ParentNavbar isAdmin={isAdmin} />
      <main className="flex-1 container mx-auto px-4 py-6 md:py-8 pb-24 md:pb-8 animate-fade-in-up">
        {children}
      </main>
    </div>
  );
}
