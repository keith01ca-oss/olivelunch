import { supabaseAdmin } from '@/lib/supabase';
import { cookies } from 'next/headers';
import KitchenClient from '@/components/admin/KitchenClient';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function KitchenPrepPage({ searchParams }: { searchParams: { date?: string, tab?: string } }) {
  const orgId = cookies().get('olive_org_id')?.value;

  // Fetch active dishes for mapping
  let dishQuery = supabaseAdmin
    .from('dishes')
    .select('id, name, category, recipe_url, ingredients, prep_time_minutes, cook_time_minutes, pack_time_seconds')
    .eq('is_active', true)
    .is('deleted_at', null);
  if (orgId) dishQuery = dishQuery.eq('org_id', orgId);
  const { data: dishes } = await dishQuery;

  return (
    <div className="space-y-6">
      <div className="print:hidden">
        <h1 className="text-3xl font-extrabold tracking-tight">Kitchen Prep</h1>
        <p className="text-muted-foreground mt-1">Calculate daily meal and ingredient totals.</p>
      </div>
      
      <KitchenClient initialDishes={dishes || []} initialDate={searchParams.date} initialTab={searchParams.tab as any} />
    </div>
  );
}
